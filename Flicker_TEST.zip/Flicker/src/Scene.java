//TODO: add your name to the author tag.

/**
 * Scene groups an image filepath, story text, and button texts into a cohesive object.
 * 
 * @authors Bret Saxby
 */
public class Scene 
{
    private String imageName;
    private String sceneText;
    private String buttonOneText;
    private String buttonTwoText;

    /**
     * Initializes all fields.
     * 
     * @param img file path
     * @param sTxt story text
     * @param b1Txt button 1 text
     * @param b2Txt button 2 text
     */
    public Scene(String img, String sTxt, String b1Txt, String b2Txt)
    {
        this.imageName = img;
        this.sceneText = sTxt;
        this.buttonOneText = b1Txt;
        this.buttonTwoText = b2Txt;                                                
    }

    //getters
    public String getImageName()
    {
        return imageName;
    }

    public String getSceneText()
    {
        return sceneText;
    }

    public String getButtonOneText()
    {
        return buttonOneText;
    }

    public String getButtonTwoText()
    {
        return buttonTwoText;
    }
}