import javax.swing.*;

//TODO: add your name to the author tag.

/**
 * Creates two JButtons with assigned actionListeners to dictate game logic.
 * 
 * @authors Bret Saxby
 */
public class Controller
{
    private Main main;
    private JButton btn1;
    private JButton btn2;
    private JPanel buttonPanel;
    private StringBuilder pathBuilder;

    /**
     * Initializes and groups two buttons to be used in Main's GUI. 
     * ActionListeners append an 'A' or 'B' char to be used in Main for Scene positioning.
     * 
     * @param main accesses Main's methods.
     */
    public Controller(Main main)   
    {
        this.main = main;
        this.btn1 = new JButton();
        this.btn2 = new JButton();
        this.buttonPanel = new JPanel();
        this.pathBuilder = new StringBuilder();

        buttonPanel.add(btn1);
        buttonPanel.add(btn2); 

        btn1.addActionListener(e -> {
            pathBuilder.append('A');
            main.updateState(pathBuilder.toString());
        });

        btn2.addActionListener(e -> {
            pathBuilder.append('B');
            main.updateState(pathBuilder.toString());
        });
    }

    /**
     * Sets button text.
     * 
     * @param text1 sets the text of btn1
     * @param text2 sets the text of btn2
     */
    public void setButtonText(String text1, String text2)
    {
        btn1.setText(text1);
        btn2.setText(text2);
    }

    public JPanel getButtonPanel()
    {
        return buttonPanel;
    }
}