import javax.swing.*;
import java.awt.*;

//TODO: add your name to the author tag.

/**
 * Main constructs the GUI, and updates changes when an action is made.
 * 
 * @authors Bret Saxby
 */
public class Main 
{   
    private JFrame frame;
    private Scene[] scenes;
    private Controller controller;
    private JLabel textLabel;
    private JLabel imageLabel;
    private JPanel buttonStoryGroup;

    /**
     * Main's constructor contains all of the game's Scenes in an array, and initializes all GUI elements.
     */
    public Main()
    {
        /*
        * This Scene[] contains all of the game's scenes.
        * The starting scene's file path has only "C", the rest have strings made up of 'A' and 'B' chars.
        * This corresponds to the logic of the game: I.E picking path 'A' from point 'BABA' leads to scene 'BABAA'
        */
        scenes = new Scene[]
        {
            new Scene("C", "This is stupid little test. \"A\" should show a meme of Snoop Dogg, \"B\" should show a Joker mushroom.",  "go to A", "Go to B"),
            new Scene("A", "Now, press \"A\" for a fish smoking, or \"B\" for just a dumb fish", "Smoking fish", "Dumb fish"),         
            new Scene("AA", "Here's your fish, the end!", "leave", "leave"),
            new Scene("AB", "Here is your fish, the end!", "leave", "leave"),
            new Scene("B", "Click \"A\" for Saul, or \"B\" for... something ig", "Saul", "Something"),
            new Scene("BA", "Pathing works for B!", "leave", "leave"),
            new Scene("BB", "Pathing works for A!", "leave", "leave"),
        };

        //initialized GUI elements
        frame = new JFrame();  
        textLabel = new JLabel();
        imageLabel = new JLabel();
        controller = new Controller(this);

        //Groups the buttonPanel and textPannel to face SOUTH in the BorderLayout
        buttonStoryGroup = new JPanel(new BorderLayout());
        buttonStoryGroup.add(textLabel, BorderLayout.NORTH);
        buttonStoryGroup.add(controller.getButtonPanel(), BorderLayout.SOUTH);
        textLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        //Initializes the first scene
        this.updateState("C");

        //Frame settings
        frame.add(imageLabel);
        frame.add(buttonStoryGroup, BorderLayout.SOUTH);
        frame.setSize(1000,700);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }    
    
    /**
     * Updates the text, button text, and image of the scene when an actionListener in Controller dictates.
     * 
     * @param path the path given by controller
     */
    public void updateState(String path)
    {
        int i = sceneIndexer(path);
        Scene scene = scenes[i];

        imageLabel.setIcon(new ImageIcon("images/" + scene.getImageName() + ".jpeg"));
        textLabel.setText(scene.getSceneText());
        controller.setButtonText(scene.getButtonOneText(), scene.getButtonTwoText());

        imageLabel.revalidate();
        imageLabel.repaint();
        textLabel.revalidate();
        textLabel.repaint();
    }

    /**
     * Calculates the correct Scene[] index using a path given by Controller.
     * 
     * @param path given by Controller's StringBuilder
     * @return the correct Scene[] index to be displayed
     */
    public int sceneIndexer(String path)
    {
        for(int i = 0; i < scenes.length; i++)
        {
            if(scenes[i].getImageName().equals(path))
                return i;
        }
        return 0;
    }

    public static void main(String[] args)
    {
        new Main();
    }
}